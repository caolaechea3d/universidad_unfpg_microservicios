package pe.com.unfpg.biblioteca.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import pe.com.unfpg.biblioteca.exception.ResourceNotFoundException;
import pe.com.unfpg.biblioteca.entity.EjemplarLibroEntity;
import pe.com.unfpg.biblioteca.repository.EjemplarLibroRepository;
import pe.com.unfpg.biblioteca.repository.LibroRepository;
import pe.com.unfpg.biblioteca.service.EjemplarLibroService;
import pe.com.unfpg.biblioteca.client.CatalogoFeignClient;
import pe.com.unfpg.biblioteca.entity.LibroEntity;

@Service
public class EjemplarLibroServiceImpl implements EjemplarLibroService {

	private final EjemplarLibroRepository repositorio;
	private final LibroRepository libroRepositorio;
	private final CatalogoFeignClient catalogoFeignClient;

	public EjemplarLibroServiceImpl(
	        EjemplarLibroRepository repositorio,
	        LibroRepository libroRepositorio,
	        CatalogoFeignClient catalogoFeignClient) {
	    this.repositorio = repositorio;
	    this.libroRepositorio = libroRepositorio;
	    this.catalogoFeignClient = catalogoFeignClient;
	}

	private EjemplarLibroEntity completar(EjemplarLibroEntity ejemplar) {
	    LibroEntity libro = libroRepositorio.findById(ejemplar.getCodlib()).orElseThrow(() -> new ResourceNotFoundException("Libro con id " + ejemplar.getCodlib() + " no existe"));
	    libro.setCategorialibro(catalogoFeignClient.getCategorialibro(libro.getCodcatl()));
	    libro.setEditorial(catalogoFeignClient.getEditorial(libro.getCodedi()));
	    ejemplar.setLibro(libro);
	    return ejemplar;
	}
	
	@Override
	public List<EjemplarLibroEntity> findAll() {
	    List<EjemplarLibroEntity> ejemplares = repositorio.findAll();
	    ejemplares.forEach(this::completar);
	    return ejemplares;
	}

	@Override
	public List<EjemplarLibroEntity> findAllCustom() {
	    List<EjemplarLibroEntity> ejemplares = repositorio.findAllCustom();
	    ejemplares.forEach(this::completar);
	    return ejemplares;
	}

	@Override
	public EjemplarLibroEntity findById(Long id) {
	    return completar(repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + id + " no existe")));
	}

    @Override
    public EjemplarLibroEntity add(EjemplarLibroEntity obj) {
        if (obj.getEstadoejemplar() == null) {
            obj.setEstadoejemplar("DISPONIBLE");
        }

        if (obj.getEstado() == null) {
            obj.setEstado(true);
        }

        return repositorio.save(obj);
    }

    @Override
    public EjemplarLibroEntity update(EjemplarLibroEntity obj, Long id) {
        EjemplarLibroEntity objeje = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + id + " no existe"));

        BeanUtils.copyProperties(obj, objeje, "codigo");

        return repositorio.save(objeje);
    }

    @Override
    public EjemplarLibroEntity delete(Long id) {
        EjemplarLibroEntity objeje = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + id + " no existe"));

        objeje.setEstado(false);

        return repositorio.save(objeje);
    }

    @Override
    public EjemplarLibroEntity enable(Long id) {
        EjemplarLibroEntity objeje = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + id + " no existe"));

        objeje.setEstado(true);

        return repositorio.save(objeje);
    }
}
