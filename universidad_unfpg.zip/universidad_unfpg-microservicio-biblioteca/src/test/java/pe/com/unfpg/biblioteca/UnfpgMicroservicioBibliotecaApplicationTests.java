package pe.com.unfpg.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnfpgMicroservicioBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
