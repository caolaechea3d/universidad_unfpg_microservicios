package pe.com.unfpg.biblioteca.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import pe.com.unfpg.biblioteca.exception.ResourceNotFoundException;
import pe.com.unfpg.biblioteca.client.CatalogoFeignClient;
import pe.com.unfpg.biblioteca.client.PersonaFeignClient;
import pe.com.unfpg.biblioteca.entity.PrestamoLibroEntity;
import pe.com.unfpg.biblioteca.repository.EjemplarLibroRepository;
import pe.com.unfpg.biblioteca.repository.PrestamoLibroRepository;
import pe.com.unfpg.biblioteca.service.PrestamoLibroService;

@Service
public class PrestamoLibroServiceImpl implements PrestamoLibroService {

    private final PrestamoLibroRepository repositorio;
    private final EjemplarLibroRepository ejemplarRepositorio;
    private final PersonaFeignClient personaFeignClient;
    private final CatalogoFeignClient catalogoFeignClient;

    public PrestamoLibroServiceImpl(
            PrestamoLibroRepository repositorio,
            EjemplarLibroRepository ejemplarRepositorio,
            PersonaFeignClient personaFeignClient,
            CatalogoFeignClient catalogoFeignClient) {

        this.repositorio = repositorio;
        this.ejemplarRepositorio = ejemplarRepositorio;
        this.personaFeignClient = personaFeignClient;
        this.catalogoFeignClient = catalogoFeignClient;
    }

    @Override
    public List<PrestamoLibroEntity> findAll() {
        List<PrestamoLibroEntity> prestamos = repositorio.findAll();

        for (PrestamoLibroEntity prestamo : prestamos) {

            prestamo.setEjemplarlibro(
                ejemplarRepositorio.findById(prestamo.getCodeje()).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + prestamo.getCodeje() + " no existe"))
            );

            prestamo.setAlumno(
                personaFeignClient.getAlumno(prestamo.getCodalu())
            );

            prestamo.setEstadoprestamolibro(
                catalogoFeignClient.getEstadoprestamolibro(prestamo.getCodestl())
            );
        }

        return prestamos;
    }

    @Override
    public List<PrestamoLibroEntity> findAllCustom() {
        List<PrestamoLibroEntity> prestamos = repositorio.findAllCustom();

        for (PrestamoLibroEntity prestamo : prestamos) {

            prestamo.setEjemplarlibro(
                ejemplarRepositorio.findById(prestamo.getCodeje()).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + prestamo.getCodeje() + " no existe"))
            );

            prestamo.setAlumno(
                personaFeignClient.getAlumno(prestamo.getCodalu())
            );

            prestamo.setEstadoprestamolibro(
                catalogoFeignClient.getEstadoprestamolibro(prestamo.getCodestl())
            );
        }

        return prestamos;
    }

    @Override
    public PrestamoLibroEntity findById(Long id) {
        PrestamoLibroEntity prestamo = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("PrestamoLibro con id " + id + " no existe"));

        prestamo.setEjemplarlibro(
            ejemplarRepositorio.findById(prestamo.getCodeje()).orElseThrow(() -> new ResourceNotFoundException("EjemplarLibro con id " + prestamo.getCodeje() + " no existe"))
        );

        prestamo.setAlumno(
            personaFeignClient.getAlumno(prestamo.getCodalu())
        );

        prestamo.setEstadoprestamolibro(
            catalogoFeignClient.getEstadoprestamolibro(prestamo.getCodestl())
        );

        return prestamo;
    }

    @Override
    public PrestamoLibroEntity add(PrestamoLibroEntity obj) {
        if (obj.getDevuelto() == null) {
            obj.setDevuelto(false);
        }

        if (obj.getEstado() == null) {
            obj.setEstado(true);
        }

        return repositorio.save(obj);
    }

    @Override
    public PrestamoLibroEntity update(PrestamoLibroEntity obj, Long id) {
        PrestamoLibroEntity objpre = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("PrestamoLibro con id " + id + " no existe"));

        BeanUtils.copyProperties(obj, objpre, "codigo");

        return repositorio.save(objpre);
    }

    @Override
    public PrestamoLibroEntity delete(Long id) {
        PrestamoLibroEntity objpre = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("PrestamoLibro con id " + id + " no existe"));

        objpre.setEstado(false);

        return repositorio.save(objpre);
    }

    @Override
    public PrestamoLibroEntity enable(Long id) {
        PrestamoLibroEntity objpre = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("PrestamoLibro con id " + id + " no existe"));

        objpre.setEstado(true);

        return repositorio.save(objpre);
    }
}