package pe.com.unfpg.biblioteca.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
    name = "unfpg-microservicio-persona",
    url = "http://localhost:9092/unfpg/api/"
)
public interface PersonaFeignClient {

    @GetMapping("/alumno/{id}")
    Object getAlumno(@PathVariable("id") Long id);
}