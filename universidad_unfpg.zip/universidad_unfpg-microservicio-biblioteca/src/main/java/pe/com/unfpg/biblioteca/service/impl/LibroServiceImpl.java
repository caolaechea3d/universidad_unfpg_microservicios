
package pe.com.unfpg.biblioteca.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import pe.com.unfpg.biblioteca.exception.ResourceNotFoundException;
import pe.com.unfpg.biblioteca.client.CatalogoFeignClient;
import pe.com.unfpg.biblioteca.entity.LibroEntity;
import pe.com.unfpg.biblioteca.repository.LibroRepository;
import pe.com.unfpg.biblioteca.service.LibroService;

@Service
public class LibroServiceImpl implements LibroService {

    private final LibroRepository repositorio;
    private final CatalogoFeignClient catalogoFeignClient;

    public LibroServiceImpl(
            LibroRepository repositorio,
            CatalogoFeignClient catalogoFeignClient) {

        this.repositorio = repositorio;
        this.catalogoFeignClient = catalogoFeignClient;
    }

    @Override
    public List<LibroEntity> findAll() {
        List<LibroEntity> libros = repositorio.findAll();

        for (LibroEntity libro : libros) {
            libro.setCategorialibro(
                catalogoFeignClient.getCategorialibro(libro.getCodcatl())
            );

            libro.setEditorial(
                catalogoFeignClient.getEditorial(libro.getCodedi())
            );
        }

        return libros;
    }

    @Override
    public List<LibroEntity> findAllCustom() {
        List<LibroEntity> libros = repositorio.findAllCustom();

        for (LibroEntity libro : libros) {
            libro.setCategorialibro(
                catalogoFeignClient.getCategorialibro(libro.getCodcatl())
            );

            libro.setEditorial(
                catalogoFeignClient.getEditorial(libro.getCodedi())
            );
        }

        return libros;
    }

    @Override
    public LibroEntity findById(Long id) {
        LibroEntity libro = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Libro con id " + id + " no existe"));

        libro.setCategorialibro(
            catalogoFeignClient.getCategorialibro(libro.getCodcatl())
        );

        libro.setEditorial(
            catalogoFeignClient.getEditorial(libro.getCodedi())
        );

        return libro;
    }

    @Override
    public LibroEntity add(LibroEntity obj) {
        return repositorio.save(obj);
    }

    @Override
    public LibroEntity update(LibroEntity obj, Long id) {
        // Buscar el valor que se va a actualizar
        LibroEntity objlib = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Libro con id " + id + " no existe"));

        // Actualizamos los valores, sin pisar el codigo
        BeanUtils.copyProperties(obj, objlib, "codigo");

        return repositorio.save(objlib);
    }

    @Override
    public LibroEntity delete(Long id) {
        // Borrado logico: cambiamos el estado
        LibroEntity objlib = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Libro con id " + id + " no existe"));

        objlib.setEstado(false);

        return repositorio.save(objlib);
    }

    @Override
    public LibroEntity enable(Long id) {
        // Habilitar: cambiamos el estado
        LibroEntity objlib = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Libro con id " + id + " no existe"));

        objlib.setEstado(true);

        return repositorio.save(objlib);
    }
}
