package pe.com.unfpg.biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "pe.com.unfpg.biblioteca.client")
public class UnfpgMicroservicioBibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnfpgMicroservicioBibliotecaApplication.class, args);
	}

}
