package pe.com.unfpg.biblioteca.entity;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity(name = "PrestamoLibroEntity")
@Table(name = "prestamolibro")
public class PrestamoLibroEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "numpre")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @Column(name = "fecpre", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaprestamo;

    @Column(name = "fecdpre")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechadevolucion;

    @Column(name = "devpre", nullable = false)
    private Boolean devuelto;

    @Column(name = "estpre", nullable = false)
    private Boolean estado;

    // Claves foráneas
    @Column(name = "codalu", nullable = false)
    private Long codalu;

    @Column(name = "codeje", nullable = false)
    private Long codeje;

    @Column(name = "codestl", nullable = false)
    private Long codestl;

    // Datos obtenidos de otros microservicios
    @Transient
    private Object alumno;

    @Transient
    private Object estadoprestamolibro;

    // Datos obtenidos del mismo microservicio
    @Transient
    private Object ejemplarlibro;
}