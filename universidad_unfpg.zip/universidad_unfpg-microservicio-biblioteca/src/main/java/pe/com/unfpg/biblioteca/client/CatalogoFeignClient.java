package pe.com.unfpg.biblioteca.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
    name = "unfpg-microservicio-catalogo",
    url = "http://localhost:9091/unfpg/api/"
)
public interface CatalogoFeignClient {

    @GetMapping("/categorialibro/{id}")
    Object getCategorialibro(@PathVariable("id") Long id);

    @GetMapping("/editorial/{id}")
    Object getEditorial(@PathVariable("id") Long id);

    @GetMapping("/estadoprestamolibro/{id}")
    Object getEstadoprestamolibro(@PathVariable("id") Long id);
}