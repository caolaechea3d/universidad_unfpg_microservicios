package pe.com.unfpg.academico.exception;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {

	private LocalDateTime fecha;
	private int estado;
	private String error;
	private String mensaje;
	private String ruta;
}
