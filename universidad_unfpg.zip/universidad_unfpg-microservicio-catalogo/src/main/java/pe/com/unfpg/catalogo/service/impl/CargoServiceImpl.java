package pe.com.unfpg.catalogo.service.impl;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.CargoEntity;
import pe.com.unfpg.catalogo.repository.CargoRepository;
import pe.com.unfpg.catalogo.service.CargoService;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class CargoServiceImpl implements CargoService {
	
	//inyeccion de dependencia hacia el repositorio
	private final CargoRepository repositorio;

	CargoServiceImpl(CargoRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<CargoEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<CargoEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public CargoEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cargo con id " + id + " no existe"));
	}
	@Override
	public CargoEntity add(CargoEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public CargoEntity update(CargoEntity obj, Long id) {
		//buscar el valor que se va actualizar
		CargoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cargo con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public CargoEntity delete(Long id) {
		//buscar el valor que se va actualizar
		CargoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cargo con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public CargoEntity enable(Long id) {
		//buscar el valor que se va actualizar
		CargoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cargo con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}


