package pe.com.unfpg.catalogo.service.impl;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.EstadoPLibroEntity;
import pe.com.unfpg.catalogo.repository.EstadoPLibroRepository;
import pe.com.unfpg.catalogo.service.EstadoPLibroService
;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class EstadoPLibroServiceImpl implements EstadoPLibroService
 {
	
	//inyeccion de dependencia hacia el repositorio
	private final EstadoPLibroRepository repositorio;

	EstadoPLibroServiceImpl(EstadoPLibroRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<EstadoPLibroEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<EstadoPLibroEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public EstadoPLibroEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoPLibro con id " + id + " no existe"));
	}
	@Override
	public EstadoPLibroEntity add(EstadoPLibroEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public EstadoPLibroEntity update(EstadoPLibroEntity obj, Long id) {
		//buscar el valor que se va actualizar
		EstadoPLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoPLibro con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public EstadoPLibroEntity delete(Long id) {
		//buscar el valor que se va actualizar
		EstadoPLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoPLibro con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public EstadoPLibroEntity enable(Long id) {
		//buscar el valor que se va actualizar
		EstadoPLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoPLibro con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}
