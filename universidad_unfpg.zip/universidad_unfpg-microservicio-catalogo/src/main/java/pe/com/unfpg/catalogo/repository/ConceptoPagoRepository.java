package pe.com.unfpg.catalogo.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import pe.com.unfpg.catalogo.entity.ConceptoPagoEntity;


public interface ConceptoPagoRepository extends JpaRepository<ConceptoPagoEntity, Long> {
	//utilizamos el JpaRepository por defecto se configura:
	//mostrar, buscar por codigo, registrar, actualizar y eliminar
	
	//agregamos un Query personalizado
	//Consulta MySQL: select * from distrito where estdis=1
	//creamos un query personalizado
	@Query("select c from ConceptoPagoEntity c where c.estado=true")
	List<ConceptoPagoEntity> findAllCustom();
}
