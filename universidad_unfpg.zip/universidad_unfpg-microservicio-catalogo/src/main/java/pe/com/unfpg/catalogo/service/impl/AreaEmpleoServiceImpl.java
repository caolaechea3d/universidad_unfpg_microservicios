package pe.com.unfpg.catalogo.service.impl;

import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.AreaEmpleoEntity;
import pe.com.unfpg.catalogo.repository.AreaEmpleoRepository;
import pe.com.unfpg.catalogo.service.AreaEmpleoService;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class AreaEmpleoServiceImpl implements AreaEmpleoService {
	
	//inyeccion de dependencia hacia el repositorio
	private final AreaEmpleoRepository repositorio;

	AreaEmpleoServiceImpl(AreaEmpleoRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<AreaEmpleoEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<AreaEmpleoEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public AreaEmpleoEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("AreaEmpleo con id " + id + " no existe"));
	}
	@Override
	public AreaEmpleoEntity add(AreaEmpleoEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public AreaEmpleoEntity update(AreaEmpleoEntity obj, Long id) {
		//buscar el valor que se va actualizar
		AreaEmpleoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("AreaEmpleo con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public AreaEmpleoEntity delete(Long id) {
		//buscar el valor que se va actualizar
		AreaEmpleoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("AreaEmpleo con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public AreaEmpleoEntity enable(Long id) {
		//buscar el valor que se va actualizar
		AreaEmpleoEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("AreaEmpleo con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}
