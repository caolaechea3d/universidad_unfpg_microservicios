package pe.com.unfpg.catalogo.service.impl;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.CategoriaLibroEntity;
import pe.com.unfpg.catalogo.repository.CategoriaLibroRepository;
import pe.com.unfpg.catalogo.service.CategoriaLibroService;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class CategoriaLibroServiceImpl implements CategoriaLibroService {
	
	//inyeccion de dependencia hacia el repositorio
	private final CategoriaLibroRepository repositorio;

	CategoriaLibroServiceImpl(CategoriaLibroRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<CategoriaLibroEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<CategoriaLibroEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public CategoriaLibroEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("CategoriaLibro con id " + id + " no existe"));
	}
	@Override
	public CategoriaLibroEntity add(CategoriaLibroEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public CategoriaLibroEntity update(CategoriaLibroEntity obj, Long id) {
		//buscar el valor que se va actualizar
		CategoriaLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("CategoriaLibro con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public CategoriaLibroEntity delete(Long id) {
		//buscar el valor que se va actualizar
		CategoriaLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("CategoriaLibro con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public CategoriaLibroEntity enable(Long id) {
		//buscar el valor que se va actualizar
		CategoriaLibroEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("CategoriaLibro con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}


