package pe.com.unfpg.catalogo.service.impl;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.EstadoMatriculaEntity;
import pe.com.unfpg.catalogo.repository.EstadoMatriculaRepository;
import pe.com.unfpg.catalogo.service.EstadoMatriculaService;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class EstadoMatriculaServiceImpl implements EstadoMatriculaService {
	
	//inyeccion de dependencia hacia el repositorio
	private final EstadoMatriculaRepository repositorio;

	EstadoMatriculaServiceImpl(EstadoMatriculaRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<EstadoMatriculaEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<EstadoMatriculaEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public EstadoMatriculaEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoMatricula con id " + id + " no existe"));
	}
	@Override
	public EstadoMatriculaEntity add(EstadoMatriculaEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public EstadoMatriculaEntity update(EstadoMatriculaEntity obj, Long id) {
		//buscar el valor que se va actualizar
		EstadoMatriculaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoMatricula con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public EstadoMatriculaEntity delete(Long id) {
		//buscar el valor que se va actualizar
		EstadoMatriculaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoMatricula con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public EstadoMatriculaEntity enable(Long id) {
		//buscar el valor que se va actualizar
		EstadoMatriculaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("EstadoMatricula con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}


