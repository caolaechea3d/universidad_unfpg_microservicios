package pe.com.unfpg.catalogo.service.impl;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import pe.com.unfpg.catalogo.exception.ResourceNotFoundException;
import pe.com.unfpg.catalogo.entity.DiaSemanaEntity;
import pe.com.unfpg.catalogo.repository.DiaSemanaRepository;
import pe.com.unfpg.catalogo.service.DiaSemanaService;
//indicamos que es un servicio @Service
@Service
//implementamos el servicio
public class DiaSemanaServiceImpl implements DiaSemanaService {
	
	//inyeccion de dependencia hacia el repositorio
	private final DiaSemanaRepository repositorio;

	DiaSemanaServiceImpl(DiaSemanaRepository repositorio) {
		this.repositorio = repositorio;
	}
	@Override
	public List<DiaSemanaEntity> findAll() {
		return repositorio.findAll();
	}
	@Override
	public List<DiaSemanaEntity> findAllCustom() {
		return repositorio.findAllCustom();
	}
	@Override
	public DiaSemanaEntity findById(Long id) {
		return repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("DiaSemana con id " + id + " no existe"));
	}
	@Override
	public DiaSemanaEntity add(DiaSemanaEntity obj) {
		return repositorio.save(obj);
	}
	@Override
	public DiaSemanaEntity update(DiaSemanaEntity obj, Long id) {
		//buscar el valor que se va actualizar
		DiaSemanaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("DiaSemana con id " + id + " no existe"));
		//actualizamos los valores
		BeanUtils.copyProperties(obj, objdis);
		return repositorio.save(objdis);
	}
	@Override
	public DiaSemanaEntity delete(Long id) {
		//buscar el valor que se va actualizar
		DiaSemanaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("DiaSemana con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(false);
		return repositorio.save(objdis);
	}
	@Override
	public DiaSemanaEntity enable(Long id) {
		//buscar el valor que se va actualizar
		DiaSemanaEntity objdis=repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException("DiaSemana con id " + id + " no existe"));
		//cambiamos el estado
		objdis.setEstado(true);
		return repositorio.save(objdis);
	}
}


