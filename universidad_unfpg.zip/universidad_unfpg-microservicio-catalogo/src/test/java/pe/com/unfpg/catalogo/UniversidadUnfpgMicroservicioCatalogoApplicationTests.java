package pe.com.unfpg.catalogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadUnfpgMicroservicioCatalogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
